# By.เอ้สายเทส
# วิธีติดตั้งบน Termux <br>
=================================== <br>
apt update && apt upgrade -y <br>
apt install python -y <br>
apt install git -y <br>
apt install nano -y <br>
pip3 install thrift <br>
pip3 install requests <br>
pip3 install rsa <br>
pip3 install bs4 <br>
pip3 install humanfriendly <br>
pip3 install pytz <br>
pip3 install antolib <br>
pip3 install gtts <br>
pip3 install googletrans <br>
git clone https://github.com/zbkngar/gaara <br>
=================================== <br>
ขอลิ้งล็อกอิน <br>
cd gaara && python3 gaara.py <br>
=================================== <br>
# สังกัด คนวัยมันส์คลับ
